export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  avatar?: string;
  role: UserRole;
  createdAt: Date;
  updatedAt: Date;
}

export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'PROPERTY_MANAGER' | 'STAFF' | 'RESIDENT' | 'VISITOR';

export interface Community {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  description?: string;
  logo?: string;
  status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
  createdAt: Date;
  updatedAt: Date;
}

export interface Resident {
  id: string;
  userId: string;
  user: User;
  communityId: string;
  community: Community;
  unitId?: string;
  unit?: Unit;
  leaseStart?: Date;
  leaseEnd?: Date;
  emergencyContact?: string;
  emergencyPhone?: string;
}

export interface Unit {
  id: string;
  communityId: string;
  unitNumber: string;
  floor?: number;
  bedrooms?: number;
  bathrooms?: number;
  squareFeet?: number;
  rentAmount?: number;
  status: 'VACANT' | 'OCCUPIED' | 'MAINTENANCE' | 'RESERVED';
}

export interface WorkOrder {
  id: string;
  residentId: string;
  resident: Resident;
  title: string;
  description: string;
  category: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  status: 'PENDING' | 'ASSIGNED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  assignedToId?: string;
  scheduledDate?: Date;
  completedAt?: Date;
  cost?: number;
  images: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Visitor {
  id: string;
  residentId: string;
  resident: Resident;
  name: string;
  email?: string;
  phone?: string;
  purpose: string;
  visitDate: Date;
  passCode: string;
  status: 'PENDING' | 'APPROVED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'DENIED';
  checkInTime?: Date;
  checkOutTime?: Date;
  vehiclePlate?: string;
  notes?: string;
}

export interface Payment {
  id: string;
  residentId: string;
  resident: Resident;
  amount: number;
  currency: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED' | 'CANCELLED';
  type: 'RENT' | 'UTILITIES' | 'SERVICE_CHARGE' | 'MAINTENANCE' | 'DEPOSIT' | 'FINE' | 'OTHER';
  description?: string;
  stripePaymentIntentId?: string;
  paidAt?: Date;
  dueDate?: Date;
}

export interface MarketplaceListing {
  id: string;
  sellerId: string;
  seller: Resident;
  communityId: string;
  community: Community;
  title: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  status: 'ACTIVE' | 'SOLD' | 'EXPIRED' | 'REMOVED';
  soldAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface IoTDevice {
  id: string;
  communityId: string;
  community: Community;
  name: string;
  type: string;
  location: string;
  serialNumber: string;
  firmware?: string;
  status: 'ONLINE' | 'OFFLINE' | 'MAINTENANCE' | 'ERROR';
  lastSeenAt?: Date;
  metadata?: Record<string, any>;
}

export interface IoTReading {
  id: string;
  deviceId: string;
  device: IoTDevice;
  temperature?: number;
  humidity?: number;
  energyUsage?: number;
  waterUsage?: number;
  occupancy?: boolean;
  motion?: boolean;
  airQuality?: number;
  noiseLevel?: number;
  recordedAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  user: User;
  title: string;
  body: string;
  type: 'PUSH' | 'EMAIL' | 'SMS' | 'IN_APP';
  data?: string;
  read: boolean;
  readAt?: Date;
  createdAt: Date;
}
