# CityOS Platform

A comprehensive smart city management platform built with modern web technologies.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        CityOS Platform                         │
├─────────────────────────────────────────────────────────────┤
│  Web Layer          │  Mobile Layer         │  API Layer     │
│  ├─ Resident Portal │  ├─ React Native App  │  ├─ NestJS     │
│  ├─ Admin Dashboard │  │   (iOS/Android)    │  ├─ GraphQL    │
│  └─ Property Mgmt   │  └─ Expo              │  ├─ Prisma     │
│                     │                       │  └─ PostgreSQL │
├─────────────────────────────────────────────────────────────┤
│  Infrastructure: Docker | Kubernetes | Terraform | AWS/GCP  │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# Install dependencies
pnpm install

# Start infrastructure
docker-compose up -d

# Run database migrations
pnpm db:push

# Start all apps in development
pnpm dev
```

## Apps

| App | Port | Description |
|-----|------|-------------|
| API | 4000 | GraphQL API + REST endpoints |
| Resident Web | 3000 | Resident self-service portal |
| Admin Web | 3001 | City administration dashboard |
| Property Web | 3002 | Property management interface |
| Mobile | Expo | iOS/Android resident app |

## Modules

- **Auth**: JWT + OAuth2 + Role-based access control
- **Communities**: Community/estate management
- **Residents**: Resident profiles, units, leases
- **Work Orders**: Maintenance request tracking
- **Visitors**: Visitor registration & gate pass
- **Payments**: Rent, utilities, service charges (Stripe)
- **Marketplace**: Community marketplace & services
- **IoT**: Smart device management & telemetry
- **Notifications**: Push, SMS, Email, In-app

## Tech Stack

- **Backend**: NestJS, GraphQL (Apollo), Prisma, PostgreSQL, Redis
- **Frontend**: Next.js 14, React Server Components, Tailwind CSS, shadcn/ui
- **Mobile**: React Native, Expo, React Navigation
- **DevOps**: Docker, Kubernetes, Terraform, GitHub Actions
