
Added:
- Amharic, Afaan Oromo, Tigrinya locale files
- Prisma localization enum placeholder
- ETB/Fayda/Telebirr implementation notes
