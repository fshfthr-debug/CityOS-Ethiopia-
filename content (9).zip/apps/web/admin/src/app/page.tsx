'use client';

import { BarChart3, Users, Wrench, CreditCard, Building2, Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { useState } from 'react';

const stats = [
  { label: 'Total Residents', value: '156', change: '+12%', up: true, icon: Users, color: 'bg-blue-500' },
  { label: 'Active Work Orders', value: '23', change: '-5%', up: false, icon: Wrench, color: 'bg-amber-500' },
  { label: 'Monthly Revenue', value: '$284,500', change: '+8.2%', up: true, icon: CreditCard, color: 'bg-emerald-500' },
  { label: 'Occupancy Rate', value: '94%', change: '+2%', up: true, icon: Building2, color: 'bg-purple-500' },
];

const recentWorkOrders = [
  { id: 'WO-1042', title: 'HVAC Repair - Building A', status: 'In Progress', priority: 'High', assigned: 'Mike Repair' },
  { id: 'WO-1041', title: 'Plumbing Issue - Unit 305', status: 'Pending', priority: 'Medium', assigned: '-' },
  { id: 'WO-1040', title: 'Light Fixture - Lobby', status: 'Completed', priority: 'Low', assigned: 'Lisa Clean' },
  { id: 'WO-1039', title: 'Security Camera - Parking', status: 'In Progress', priority: 'High', assigned: 'Sam Guard' },
];

const revenueData = [
  { month: 'Jan', revenue: 245000, expenses: 180000 },
  { month: 'Feb', revenue: 252000, expenses: 185000 },
  { month: 'Mar', revenue: 260000, expenses: 190000 },
  { month: 'Apr', revenue: 268000, expenses: 195000 },
  { month: 'May', revenue: 275000, expenses: 200000 },
  { month: 'Jun', revenue: 284500, expenses: 205000 },
];

export default function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300`}>
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center shrink-0">
              <span className="text-white font-bold text-sm">C</span>
            </div>
            {sidebarOpen && <span className="font-bold text-lg text-gray-900 dark:text-white">CityOS Admin</span>}
          </div>
        </div>
        <nav className="p-2 space-y-1">
          {[
            { icon: Activity, label: 'Dashboard', active: true },
            { icon: Users, label: 'Residents' },
            { icon: Building2, label: 'Communities' },
            { icon: Wrench, label: 'Work Orders' },
            { icon: CreditCard, label: 'Payments' },
            { icon: BarChart3, label: 'Analytics' },
          ].map((item) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                item.active
                  ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400'
                  : 'text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
              }`}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              {sidebarOpen && item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard Overview</h1>
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Sunset Heights Residences • June 2026</p>
            </div>
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {sidebarOpen ? '←' : '→'}
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className={`text-xs font-medium flex items-center gap-1 ${stat.up ? 'text-emerald-600' : 'text-red-600'}`}>
                      {stat.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      {stat.change}
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Charts & Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Revenue vs Expenses</h2>
              <div className="h-64 flex items-end gap-2">
                {revenueData.map((d) => (
                  <div key={d.month} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full flex gap-1 items-end" style={{ height: '200px' }}>
                      <div className="flex-1 bg-primary-500 rounded-t" style={{ height: `${(d.revenue / 300000) * 100}%` }} />
                      <div className="flex-1 bg-red-400 rounded-t" style={{ height: `${(d.expenses / 300000) * 100}%` }} />
                    </div>
                    <span className="text-xs text-gray-500">{d.month}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-primary-500 rounded" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Revenue</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-400 rounded" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Expenses</span>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Work Orders</h2>
              <div className="space-y-3">
                {recentWorkOrders.map((wo) => (
                  <div key={wo.id} className="p-3 rounded-lg border border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-gray-500">{wo.id}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        wo.status === 'Completed' ? 'bg-emerald-100 text-emerald-700' :
                        wo.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                        'bg-amber-100 text-amber-700'
                      }`}>{wo.status}</span>
                    </div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white mt-1">{wo.title}</p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-gray-500">{wo.assigned}</span>
                      <span className={`text-xs ${wo.priority === 'High' ? 'text-red-500' : 'text-gray-400'}`}>{wo.priority}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
