'use client';

import { Package, Wrench, Users, CreditCard, Bell } from 'lucide-react';

const activities = [
  { icon: Package, text: 'Package delivered to front desk', time: '10 min ago', color: 'text-blue-500' },
  { icon: Wrench, text: 'Work order #42 assigned to Mike', time: '2 hours ago', color: 'text-amber-500' },
  { icon: Users, text: 'Visitor Sarah approved for today', time: '3 hours ago', color: 'text-emerald-500' },
  { icon: CreditCard, text: 'Payment of $1,800 confirmed', time: '1 day ago', color: 'text-purple-500' },
  { icon: Bell, text: 'Community BBQ event this Saturday', time: '2 days ago', color: 'text-rose-500' },
];

export function RecentActivity() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h2>
      <div className="space-y-4">
        {activities.map((activity, i) => {
          const Icon = activity.icon;
          return (
            <div key={i} className="flex items-start gap-3">
              <div className={`mt-0.5 ${activity.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-700 dark:text-gray-300">{activity.text}</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">{activity.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
