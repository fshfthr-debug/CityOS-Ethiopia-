'use client';

import Link from 'next/link';
import { Wrench, Users, CreditCard, ShoppingBag, FileText, Phone } from 'lucide-react';

const actions = [
  { label: 'New Work Order', href: '/work-orders/new', icon: Wrench, color: 'bg-blue-500 hover:bg-blue-600' },
  { label: 'Register Visitor', href: '/visitors/new', icon: Users, color: 'bg-emerald-500 hover:bg-emerald-600' },
  { label: 'Make Payment', href: '/payments/new', icon: CreditCard, color: 'bg-amber-500 hover:bg-amber-600' },
  { label: 'Sell Item', href: '/marketplace/new', icon: ShoppingBag, color: 'bg-purple-500 hover:bg-purple-600' },
  { label: 'View Documents', href: '/documents', icon: FileText, color: 'bg-gray-500 hover:bg-gray-600' },
  { label: 'Contact Management', href: '/contact', icon: Phone, color: 'bg-rose-500 hover:bg-rose-600' },
];

export function QuickActions() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.label}
              href={action.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg text-white text-sm font-medium transition-colors ${action.color}`}
            >
              <Icon className="w-4 h-4" />
              {action.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
