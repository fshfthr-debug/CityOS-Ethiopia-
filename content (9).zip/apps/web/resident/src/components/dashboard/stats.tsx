'use client';

import { Wrench, CreditCard, Users, Bell } from 'lucide-react';

const stats = [
  {
    label: 'Work Orders',
    value: '3',
    subtext: '1 in progress',
    icon: Wrench,
    color: 'bg-blue-500',
    lightColor: 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
  },
  {
    label: 'Due Payments',
    value: '$1,850',
    subtext: 'Due in 5 days',
    icon: CreditCard,
    color: 'bg-amber-500',
    lightColor: 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400',
  },
  {
    label: 'Visitors Today',
    value: '2',
    subtext: '1 checked in',
    icon: Users,
    color: 'bg-emerald-500',
    lightColor: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
  },
  {
    label: 'Notifications',
    value: '5',
    subtext: '3 unread',
    icon: Bell,
    color: 'bg-purple-500',
    lightColor: 'bg-purple-50 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400',
  },
];

export function DashboardStats() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <div
            key={stat.label}
            className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{stat.value}</p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{stat.subtext}</p>
              </div>
              <div className={`p-2.5 rounded-lg ${stat.lightColor}`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
