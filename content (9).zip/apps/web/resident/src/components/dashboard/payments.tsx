'use client';

import Link from 'next/link';
import { CreditCard, ArrowRight, CheckCircle, Clock } from 'lucide-react';

const payments = [
  { id: '1', description: 'Monthly Rent - June 2026', amount: 1800, status: 'PAID', date: 'Jun 1, 2026' },
  { id: '2', description: 'Utilities - May 2026', amount: 145.5, status: 'PAID', date: 'May 28, 2026' },
  { id: '3', description: 'Service Charge - Q2 2026', amount: 250, status: 'DUE', date: 'Due Jun 15, 2026' },
];

export function PaymentsWidget() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Payments</h2>
        <Link href="/payments" className="text-sm text-primary-600 hover:text-primary-700 flex items-center gap-1">
          View All <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="space-y-3">
        {payments.map((payment) => (
          <div
            key={payment.id}
            className="flex items-center justify-between p-3 rounded-lg border border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${
                payment.status === 'PAID'
                  ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20'
                  : 'bg-amber-50 text-amber-600 dark:bg-amber-900/20'
              }`}>
                {payment.status === 'PAID' ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{payment.description}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{payment.date}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-gray-900 dark:text-white">${payment.amount.toFixed(2)}</p>
              <span className={`text-xs ${
                payment.status === 'PAID' ? 'text-emerald-600' : 'text-amber-600'
              }`}>
                {payment.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
