'use client';

import { Thermometer, Droplets, Wind, Activity, Wifi, WifiOff } from 'lucide-react';

const devices = [
  { name: 'Living Room Thermostat', type: 'THERMOSTAT', value: '72°F', status: 'ONLINE', icon: Thermometer, color: 'text-orange-500' },
  { name: 'Front Door Lock', type: 'SMART_LOCK', value: 'Locked', status: 'ONLINE', icon: Activity, color: 'text-emerald-500' },
  { name: 'Air Quality Sensor', type: 'SENSOR', value: 'Good (45 AQI)', status: 'ONLINE', icon: Wind, color: 'text-blue-500' },
  { name: 'Water Meter', type: 'WATER_METER', value: '124 gal/day', status: 'OFFLINE', icon: Droplets, color: 'text-cyan-500' },
];

export function IoTDevices() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Smart Devices</h2>
      <div className="space-y-3">
        {devices.map((device) => {
          const Icon = device.icon;
          return (
            <div
              key={device.name}
              className="flex items-center justify-between p-3 rounded-lg border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-5 h-5 ${device.color}`} />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{device.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{device.value}</p>
                </div>
              </div>
              {device.status === 'ONLINE' ? (
                <Wifi className="w-4 h-4 text-emerald-500" />
              ) : (
                <WifiOff className="w-4 h-4 text-red-400" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
