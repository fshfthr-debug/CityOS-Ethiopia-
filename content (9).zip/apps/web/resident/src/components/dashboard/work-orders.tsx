'use client';

import Link from 'next/link';
import { Wrench, Clock, CheckCircle, AlertCircle, ArrowRight } from 'lucide-react';

const workOrders = [
  { id: '1', title: 'Leaky faucet in kitchen', status: 'IN_PROGRESS', priority: 'MEDIUM', date: '2 days ago' },
  { id: '2', title: 'AC not cooling properly', status: 'PENDING', priority: 'HIGH', date: '1 day ago' },
  { id: '3', title: 'Light fixture replacement', status: 'COMPLETED', priority: 'LOW', date: '5 days ago' },
];

const statusConfig = {
  PENDING: { icon: Clock, color: 'text-amber-600 bg-amber-50 dark:bg-amber-900/20', label: 'Pending' },
  IN_PROGRESS: { icon: Wrench, color: 'text-blue-600 bg-blue-50 dark:bg-blue-900/20', label: 'In Progress' },
  COMPLETED: { icon: CheckCircle, color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20', label: 'Completed' },
};

const priorityConfig = {
  LOW: 'text-gray-500',
  MEDIUM: 'text-amber-500',
  HIGH: 'text-red-500',
  URGENT: 'text-red-600 font-bold',
};

export function WorkOrdersWidget() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Work Orders</h2>
        <Link href="/work-orders" className="text-sm text-primary-600 hover:text-primary-700 flex items-center gap-1">
          View All <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="space-y-3">
        {workOrders.map((order) => {
          const config = statusConfig[order.status as keyof typeof statusConfig];
          const StatusIcon = config.icon;
          return (
            <div
              key={order.id}
              className="flex items-center gap-3 p-3 rounded-lg border border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
            >
              <div className={`p-2 rounded-lg ${config.color}`}>
                <StatusIcon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{order.title}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{order.date}</p>
              </div>
              <span className={`text-xs ${priorityConfig[order.priority as keyof typeof priorityConfig]}`}>
                {order.priority}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
