'use client';
import { CreditCard, Download, Calendar } from 'lucide-react';

const payments = [
  { id: 'PAY-2026-001', description: 'Monthly Rent - June 2026', amount: 1800, status: 'Paid', date: 'Jun 1, 2026', method: 'Credit Card ****4242' },
  { id: 'PAY-2026-002', description: 'Utilities - May 2026', amount: 145.5, status: 'Paid', date: 'May 28, 2026', method: 'Bank Transfer' },
  { id: 'PAY-2026-003', description: 'Service Charge - Q2 2026', amount: 250, status: 'Due', date: 'Due Jun 15, 2026', method: '-' },
  { id: 'PAY-2026-004', description: 'Maintenance Fee', amount: 75, status: 'Paid', date: 'May 15, 2026', method: 'Credit Card ****4242' },
];

export default function PaymentsPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Payments</h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">View and manage your payments</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">
          <CreditCard className="w-4 h-4" /> Make Payment
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Total Due</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">$1,850.00</p>
          <p className="text-xs text-amber-600 mt-1">Due by June 15, 2026</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Total Paid (YTD)</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">$10,920.50</p>
          <p className="text-xs text-emerald-600 mt-1">+8.2% vs last year</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Next Payment</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">$1,800.00</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Monthly Rent - July 2026</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
          <h2 className="font-semibold text-gray-900 dark:text-white">Payment History</h2>
          <button className="flex items-center gap-1 text-sm text-primary-600 hover:text-primary-700">
            <Download className="w-4 h-4" /> Export
          </button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">ID</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Description</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Amount</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Status</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Method</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                <td className="py-3 px-4 font-mono text-xs text-gray-500">{p.id}</td>
                <td className="py-3 px-4 font-medium text-gray-900 dark:text-white">{p.description}</td>
                <td className="py-3 px-4 font-semibold text-gray-900 dark:text-white">${p.amount.toFixed(2)}</td>
                <td className="py-3 px-4">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    p.status === 'Paid' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30' :
                    'bg-amber-100 text-amber-700 dark:bg-amber-900/30'
                  }`}>{p.status}</span>
                </td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{p.method}</td>
                <td className="py-3 px-4 text-gray-500 dark:text-gray-400">{p.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
