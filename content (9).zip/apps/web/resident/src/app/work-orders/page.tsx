'use client';
import { Wrench, Plus, Filter } from 'lucide-react';

const workOrders = [
  { id: 'WO-1042', title: 'Leaky faucet in kitchen', status: 'In Progress', priority: 'Medium', category: 'Plumbing', date: 'Jun 5, 2026', assigned: 'Mike Repair' },
  { id: 'WO-1041', title: 'AC not cooling properly', status: 'Pending', priority: 'High', category: 'HVAC', date: 'Jun 6, 2026', assigned: '-' },
  { id: 'WO-1040', title: 'Light fixture replacement', status: 'Completed', priority: 'Low', category: 'Electrical', date: 'Jun 1, 2026', assigned: 'Lisa Clean' },
  { id: 'WO-1039', title: 'Bathroom tile repair', status: 'Completed', priority: 'Medium', category: 'General', date: 'May 28, 2026', assigned: 'Mike Repair' },
];

export default function WorkOrdersPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Work Orders</h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Manage and track maintenance requests</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">
            <Plus className="w-4 h-4" /> New Request
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">ID</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Title</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Category</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Priority</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Status</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Assigned</th>
              <th className="text-left py-3 px-4 font-medium text-gray-500 dark:text-gray-400">Date</th>
            </tr>
          </thead>
          <tbody>
            {workOrders.map((wo) => (
              <tr key={wo.id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                <td className="py-3 px-4 font-mono text-xs text-gray-500">{wo.id}</td>
                <td className="py-3 px-4 font-medium text-gray-900 dark:text-white">{wo.title}</td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{wo.category}</td>
                <td className="py-3 px-4">
                  <span className={`text-xs font-medium ${
                    wo.priority === 'High' ? 'text-red-600' :
                    wo.priority === 'Medium' ? 'text-amber-600' : 'text-gray-500'
                  }`}>{wo.priority}</span>
                </td>
                <td className="py-3 px-4">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    wo.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30' :
                    wo.status === 'In Progress' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30' :
                    'bg-amber-100 text-amber-700 dark:bg-amber-900/30'
                  }`}>{wo.status}</span>
                </td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{wo.assigned}</td>
                <td className="py-3 px-4 text-gray-500 dark:text-gray-400">{wo.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
