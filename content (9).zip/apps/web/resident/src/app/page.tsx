'use client';

import { DashboardStats } from '@/components/dashboard/stats';
import { QuickActions } from '@/components/dashboard/quick-actions';
import { RecentActivity } from '@/components/dashboard/recent-activity';
import { IoTDevices } from '@/components/dashboard/iot-devices';
import { WorkOrdersWidget } from '@/components/dashboard/work-orders';
import { PaymentsWidget } from '@/components/dashboard/payments';

export default function DashboardPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Welcome back, John!
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Here's what's happening in your community today
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500 dark:text-gray-400">Unit 101</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Sunset Heights</p>
        </div>
      </div>

      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <QuickActions />
          <WorkOrdersWidget />
          <PaymentsWidget />
        </div>
        <div className="space-y-6">
          <IoTDevices />
          <RecentActivity />
        </div>
      </div>
    </div>
  );
}
