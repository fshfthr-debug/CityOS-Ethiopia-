/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  transpilePackages: ['@cityos/ui', '@cityos/types', '@cityos/utils'],
  images: {
    remotePatterns: [
      { hostname: 'localhost' },
      { hostname: '*.amazonaws.com' },
    ],
  },
};

module.exports = nextConfig;
