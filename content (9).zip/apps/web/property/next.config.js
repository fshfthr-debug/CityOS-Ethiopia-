/** @type {import('next').NextConfig} */
const nextConfig = { output: 'standalone', transpilePackages: ['@cityos/ui', '@cityos/types', '@cityos/utils'] };
module.exports = nextConfig;
