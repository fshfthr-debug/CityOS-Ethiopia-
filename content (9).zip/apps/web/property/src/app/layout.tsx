import { Inter } from 'next/font/google';
import './globals.css';
const inter = Inter({ subsets: ['latin'] });
export const metadata = { title: 'CityOS - Property Manager', description: 'Property management interface' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body className={inter.className + " bg-gray-50 dark:bg-gray-900"}>{children}</body></html>;
}
