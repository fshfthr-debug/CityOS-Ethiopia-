'use client';
import { Building2, Users, Wrench, DollarSign, TrendingUp, ArrowUpRight } from 'lucide-react';
export default function PropertyDashboard() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Property Management</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Units', value: '48', icon: Building2, color: 'bg-blue-500' },
          { label: 'Occupied', value: '45', icon: Users, color: 'bg-emerald-500' },
          { label: 'Open Tickets', value: '12', icon: Wrench, color: 'bg-amber-500' },
          { label: 'Revenue MTD', value: '$86,400', icon: DollarSign, color: 'bg-purple-500' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
              <div className={`w-10 h-10 ${s.color} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{s.value}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{s.label}</p>
            </div>
          );
        })}
      </div>
      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Unit Overview</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-2 px-3 text-gray-500 dark:text-gray-400 font-medium">Unit</th>
                <th className="text-left py-2 px-3 text-gray-500 dark:text-gray-400 font-medium">Resident</th>
                <th className="text-left py-2 px-3 text-gray-500 dark:text-gray-400 font-medium">Status</th>
                <th className="text-left py-2 px-3 text-gray-500 dark:text-gray-400 font-medium">Rent</th>
                <th className="text-left py-2 px-3 text-gray-500 dark:text-gray-400 font-medium">Lease End</th>
              </tr>
            </thead>
            <tbody>
              {[
                { unit: '101', resident: 'John Smith', status: 'Occupied', rent: '$1,800', lease: 'Dec 31, 2025' },
                { unit: '102', resident: 'Sarah Johnson', status: 'Occupied', rent: '$2,400', lease: 'Jun 30, 2026' },
                { unit: '103', resident: '-', status: 'Vacant', rent: '$2,800', lease: '-' },
                { unit: '201', resident: 'Michael Williams', status: 'Occupied', rent: '$2,400', lease: 'Mar 31, 2026' },
                { unit: '202', resident: 'Emily Brown', status: 'Occupied', rent: '$3,500', lease: 'Sep 30, 2026' },
              ].map((row) => (
                <tr key={row.unit} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="py-2 px-3 font-medium text-gray-900 dark:text-white">{row.unit}</td>
                  <td className="py-2 px-3 text-gray-600 dark:text-gray-300">{row.resident}</td>
                  <td className="py-2 px-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      row.status === 'Occupied' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'
                    }`}>{row.status}</span>
                  </td>
                  <td className="py-2 px-3 text-gray-600 dark:text-gray-300">{row.rent}</td>
                  <td className="py-2 px-3 text-gray-600 dark:text-gray-300">{row.lease}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
