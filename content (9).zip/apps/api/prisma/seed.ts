import { PrismaClient, UserRole, UnitStatus, WorkOrderStatus, Priority, VisitorStatus, PaymentStatus, PaymentType, ListingStatus, DeviceType, DeviceStatus, CommunityStatus } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const admin = await prisma.user.create({
    data: {
      email: 'admin@cityos.local',
      passwordHash: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNiAYMyzJ/I1i', // password: admin123
      firstName: 'System',
      lastName: 'Administrator',
      role: UserRole.ADMIN,
    },
  });

  // Create community
  const community = await prisma.community.create({
    data: {
      name: 'Sunset Heights Residences',
      address: '123 Sunset Boulevard',
      city: 'Los Angeles',
      state: 'CA',
      zipCode: '90028',
      description: 'A premium smart community with modern amenities and IoT integration.',
    },
  });

  // Create units
  const units = await Promise.all(
    Array.from({ length: 20 }, (_, i) => {
      const floor = Math.floor(i / 4) + 1;
      const unitNum = `${floor}0${(i % 4) + 1}`;
      return prisma.unit.create({
        data: {
          communityId: community.id,
          unitNumber: unitNum,
          floor,
          bedrooms: [1, 2, 2, 3][i % 4],
          bathrooms: [1, 1.5, 2, 2.5][i % 4],
          squareFeet: [650, 900, 1100, 1400][i % 4],
          rentAmount: [1800, 2400, 2800, 3500][i % 4],
          status: i < 15 ? UnitStatus.OCCUPIED : UnitStatus.VACANT,
        },
      });
    })
  );

  // Create residents
  const residents = await Promise.all(
    Array.from({ length: 15 }, async (_, i) => {
      const user = await prisma.user.create({
        data: {
          email: `resident${i + 1}@cityos.local`,
          passwordHash: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNiAYMyzJ/I1i',
          firstName: ['John', 'Sarah', 'Michael', 'Emily', 'David', 'Jessica', 'Robert', 'Amanda', 'James', 'Lisa', 'Christopher', 'Jennifer', 'Matthew', 'Ashley', 'Daniel'][i],
          lastName: ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson'][i],
          phone: `+1-555-${String(1000 + i).padStart(4, '0')}`,
          role: UserRole.RESIDENT,
        },
      });

      return prisma.resident.create({
        data: {
          userId: user.id,
          communityId: community.id,
          unitId: units[i].id,
          leaseStart: new Date(2024, 0, 1),
          leaseEnd: new Date(2025, 11, 31),
          emergencyContact: 'Emergency Contact',
          emergencyPhone: '+1-555-9999',
        },
      });
    })
  );

  // Create staff
  const staffMembers = await Promise.all(
    ['Maintenance', 'Security', 'Cleaning', 'Management'].map((dept, i) =>
      prisma.staff.create({
        data: {
          userId: admin.id,
          firstName: ['Mike', 'Sam', 'Lisa', 'Karen'][i],
          lastName: ['Repair', 'Guard', 'Clean', 'Manage'][i],
          email: `${dept.toLowerCase()}@cityos.local`,
          role: ['MAINTENANCE', 'SECURITY', 'CLEANING', 'MANAGEMENT'][i] as any,
          department: dept,
        },
      })
    )
  );

  // Create work orders
  await Promise.all(
    Array.from({ length: 25 }, (_, i) => {
      const statuses = [WorkOrderStatus.PENDING, WorkOrderStatus.ASSIGNED, WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.COMPLETED];
      const priorities = [Priority.LOW, Priority.MEDIUM, Priority.HIGH, Priority.URGENT];
      const categories = ['Plumbing', 'Electrical', 'HVAC', 'Appliance', 'General', 'Security'];

      return prisma.workOrder.create({
        data: {
          residentId: residents[i % residents.length].id,
          title: `${categories[i % categories.length]} Issue #${i + 1}`,
          description: `Reported ${categories[i % categories.length].toLowerCase()} issue requiring attention.`,
          category: categories[i % categories.length],
          priority: priorities[i % priorities.length],
          status: statuses[i % statuses.length],
          assignedToId: i > 5 ? staffMembers[i % staffMembers.length].id : null,
          scheduledDate: i > 10 ? new Date(Date.now() + (i * 86400000)) : null,
        },
      });
    })
  );

  // Create visitors
  await Promise.all(
    Array.from({ length: 10 }, (_, i) => {
      const statuses = [VisitorStatus.PENDING, VisitorStatus.APPROVED, VisitorStatus.CHECKED_IN, VisitorStatus.CHECKED_OUT];
      return prisma.visitor.create({
        data: {
          residentId: residents[i % residents.length].id,
          name: `Visitor ${i + 1}`,
          email: `visitor${i + 1}@example.com`,
          phone: `+1-555-${String(2000 + i).padStart(4, '0')}`,
          purpose: ['Delivery', 'Guest', 'Service', 'Interview', 'Meeting'][i % 5],
          visitDate: new Date(Date.now() + (i * 86400000)),
          passCode: `VIS${String(1000 + i).padStart(4, '0')}`,
          status: statuses[i % statuses.length],
          vehiclePlate: i % 3 === 0 ? `CA-${String(1000 + i).padStart(4, '0')}` : null,
        },
      });
    })
  );

  // Create payments
  await Promise.all(
    Array.from({ length: 20 }, (_, i) => {
      const types = [PaymentType.RENT, PaymentType.UTILITIES, PaymentType.SERVICE_CHARGE, PaymentType.MAINTENANCE];
      const statuses = [PaymentStatus.COMPLETED, PaymentStatus.PENDING, PaymentStatus.COMPLETED, PaymentStatus.COMPLETED];
      return prisma.payment.create({
        data: {
          residentId: residents[i % residents.length].id,
          amount: [1800, 2400, 2800, 3500, 150, 200, 300][i % 7],
          currency: 'USD',
          status: statuses[i % statuses.length],
          type: types[i % types.length],
          description: `${types[i % types.length]} payment for ${new Date().toLocaleString('default', { month: 'long' })}`,
          dueDate: new Date(Date.now() + ((i % 30) * 86400000)),
          paidAt: statuses[i % statuses.length] === PaymentStatus.COMPLETED ? new Date() : null,
        },
      });
    })
  );

  // Create marketplace listings
  await Promise.all(
    Array.from({ length: 8 }, (_, i) => {
      const categories = ['Furniture', 'Electronics', 'Services', 'Vehicles', 'Clothing', 'Home Goods'];
      return prisma.marketplaceListing.create({
        data: {
          sellerId: residents[i % residents.length].id,
          communityId: community.id,
          title: `${categories[i % categories.length]} for Sale #${i + 1}`,
          description: `High quality ${categories[i % categories.length].toLowerCase()} in excellent condition.`,
          price: [50, 100, 200, 500, 25, 75, 150, 300][i],
          category: categories[i % categories.length],
          status: i < 6 ? ListingStatus.ACTIVE : ListingStatus.SOLD,
          soldAt: i >= 6 ? new Date() : null,
        },
      });
    })
  );

  // Create IoT devices
  const devices = await Promise.all(
    Array.from({ length: 12 }, (_, i) => {
      const types = [DeviceType.THERMOSTAT, DeviceType.SMART_LOCK, DeviceType.CAMERA, DeviceType.SENSOR, DeviceType.SMART_METER, DeviceType.LIGHTING];
      return prisma.iotDevice.create({
        data: {
          communityId: community.id,
          name: `${types[i % types.length]} ${Math.floor(i / 6) + 1}-${(i % 6) + 1}`,
          type: types[i % types.length],
          location: ['Lobby', 'Unit 101', 'Unit 102', 'Parking', 'Gym', 'Pool', 'Hallway A', 'Unit 201', 'Unit 202', 'Roof', 'Basement', 'Gate'][i],
          serialNumber: `IOT-${String(10000 + i).padStart(5, '0')}`,
          firmware: `v2.${i % 5}.${i % 10}`,
          status: i < 10 ? DeviceStatus.ONLINE : DeviceStatus.OFFLINE,
          lastSeenAt: new Date(),
          metadata: JSON.stringify({ manufacturer: ['Nest', 'Ring', 'Philips', 'Honeywell', 'Ecobee', 'August'][i % 6] }),
        },
      });
    })
  );

  // Create IoT readings
  await Promise.all(
    devices.flatMap(device =>
      Array.from({ length: 24 }, (_, i) => {
        const baseTemp = 68 + Math.random() * 10;
        return prisma.iotReading.create({
          data: {
            deviceId: device.id,
            temperature: device.type === 'THERMOSTAT' || device.type === 'SENSOR' ? baseTemp : null,
            humidity: device.type === 'SENSOR' ? 40 + Math.random() * 30 : null,
            energyUsage: device.type === 'SMART_METER' ? Math.random() * 5 : null,
            waterUsage: device.type === 'WATER_METER' ? Math.random() * 2 : null,
            occupancy: device.type === 'SENSOR' ? Math.random() > 0.3 : null,
            motion: device.type === 'CAMERA' || device.type === 'SENSOR' ? Math.random() > 0.7 : null,
            airQuality: device.type === 'AIR_QUALITY' ? 50 + Math.random() * 50 : null,
            noiseLevel: device.type === 'SENSOR' ? 30 + Math.random() * 40 : null,
            recordedAt: new Date(Date.now() - (i * 3600000)),
          },
        });
      })
    )
  );

  // Create notifications
  await Promise.all(
    Array.from({ length: 15 }, (_, i) => {
      const types = ['PUSH', 'EMAIL', 'SMS', 'IN_APP'];
      return prisma.notification.create({
        data: {
          userId: residents[i % residents.length].userId,
          title: ['Work Order Update', 'Payment Due', 'Visitor Arrived', 'Community Event', 'Package Delivered'][i % 5],
          body: `Notification ${i + 1}: ${['Your work order has been assigned', 'Payment of $200 is due soon', 'Your visitor has checked in', 'Community BBQ this Saturday', 'Your package is at the front desk'][i % 5]}`,
          type: types[i % types.length] as any,
          read: i < 8,
          readAt: i < 8 ? new Date() : null,
        },
      });
    })
  );

  console.log('✅ Seeding completed!');
  console.log(`   - 1 Admin user`);
  console.log(`   - 1 Community`);
  console.log(`   - 20 Units`);
  console.log(`   - 15 Residents`);
  console.log(`   - 4 Staff members`);
  console.log(`   - 25 Work orders`);
  console.log(`   - 10 Visitors`);
  console.log(`   - 20 Payments`);
  console.log(`   - 8 Marketplace listings`);
  console.log(`   - 12 IoT devices`);
  console.log(`   - ${12 * 24} IoT readings`);
  console.log(`   - 15 Notifications`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
