import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('Payment')
export class PaymentsResolver {
  constructor(private service: PaymentsService) {}

  @Query('payments')
  @UseGuards(GqlAuthGuard)
  async getPayments(@Args('residentId', { nullable: true }) residentId?: string) {
    return this.service.findAll(residentId);
  }

  @Mutation('createPayment')
  @UseGuards(GqlAuthGuard)
  async createPayment(
    @Args('residentId') residentId: string,
    @Args('amount') amount: number,
    @Args('currency', { nullable: true }) currency?: string,
  ) {
    return this.service.createPaymentIntent(residentId, amount, currency);
  }
}