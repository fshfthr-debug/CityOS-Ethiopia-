import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

@Injectable()
export class PaymentsService {
  private stripe: Stripe;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.stripe = new Stripe(configService.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2024-02-01' as any,
    });
  }

  async findAll(residentId?: string) {
    const where = residentId ? { residentId } : {};
    return this.prisma.payment.findMany({
      where,
      include: { resident: { include: { user: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async createPaymentIntent(residentId: string, amount: number, currency: string = 'usd') {
    const resident = await this.prisma.resident.findUnique({
      where: { id: residentId },
      include: { user: true },
    });

    const paymentIntent = await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency,
      metadata: { residentId, email: resident?.user.email },
    });

    return this.prisma.payment.create({
      data: {
        residentId,
        amount,
        currency,
        status: 'PENDING',
        stripePaymentIntentId: paymentIntent.id,
        description: 'Service charge payment',
      },
    });
  }

  async confirmPayment(stripePaymentIntentId: string) {
    return this.prisma.payment.update({
      where: { stripePaymentIntentId },
      data: { status: 'COMPLETED', paidAt: new Date() },
    });
  }
}