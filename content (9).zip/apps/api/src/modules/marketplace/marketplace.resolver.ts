import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { MarketplaceService } from './marketplace.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('MarketplaceListing')
export class MarketplaceResolver {
  constructor(private service: MarketplaceService) {}

  @Query('marketplaceListings')
  @UseGuards(GqlAuthGuard)
  async getListings(
    @Args('communityId', { nullable: true }) communityId?: string,
    @Args('category', { nullable: true }) category?: string,
  ) {
    return this.service.findAll(communityId, category);
  }

  @Mutation('createMarketplaceListing')
  @UseGuards(GqlAuthGuard)
  async create(@Args('input') input: any) {
    return this.service.create(input);
  }

  @Mutation('markListingAsSold')
  @UseGuards(GqlAuthGuard)
  async markSold(@Args('id') id: string) {
    return this.service.markAsSold(id);
  }
}