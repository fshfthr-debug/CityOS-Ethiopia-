import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class MarketplaceService {
  constructor(private prisma: PrismaService) {}

  async findAll(communityId?: string, category?: string) {
    const where: any = { status: 'ACTIVE' };
    if (communityId) where.communityId = communityId;
    if (category) where.category = category;
    return this.prisma.marketplaceListing.findMany({
      where,
      include: { seller: { include: { user: true } }, community: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    return this.prisma.marketplaceListing.findUnique({
      where: { id },
      include: { seller: true, community: true },
    });
  }

  async create(data: any) {
    return this.prisma.marketplaceListing.create({
      data: { ...data, status: 'ACTIVE' },
      include: { seller: true },
    });
  }

  async markAsSold(id: string) {
    return this.prisma.marketplaceListing.update({
      where: { id },
      data: { status: 'SOLD', soldAt: new Date() },
    });
  }
}