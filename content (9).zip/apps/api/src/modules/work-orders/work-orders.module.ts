import { Module } from '@nestjs/common';
import { WorkOrdersResolver } from './work-orders.resolver';
import { WorkOrdersService } from './work-orders.service';

@Module({
  providers: [WorkOrdersResolver, WorkOrdersService],
})
export class WorkOrdersModule {}