import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

export enum WorkOrderStatus {
  PENDING = 'PENDING',
  ASSIGNED = 'ASSIGNED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

@Injectable()
export class WorkOrdersService {
  constructor(private prisma: PrismaService) {}

  async findAll(residentId?: string, status?: string) {
    const where: any = {};
    if (residentId) where.residentId = residentId;
    if (status) where.status = status;
    return this.prisma.workOrder.findMany({
      where,
      include: { resident: { include: { user: true } }, assignedTo: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    return this.prisma.workOrder.findUnique({
      where: { id },
      include: { resident: true, assignedTo: true, comments: true },
    });
  }

  async create(data: any) {
    return this.prisma.workOrder.create({
      data: { ...data, status: 'PENDING' },
      include: { resident: true },
    });
  }

  async updateStatus(id: string, status: WorkOrderStatus, assignedToId?: string) {
    const data: any = { status };
    if (assignedToId) data.assignedToId = assignedToId;
    return this.prisma.workOrder.update({
      where: { id },
      data,
      include: { assignedTo: true },
    });
  }
}