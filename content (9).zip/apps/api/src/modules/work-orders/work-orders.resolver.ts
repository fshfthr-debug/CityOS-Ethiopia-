import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { WorkOrdersService, WorkOrderStatus } from './work-orders.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('WorkOrder')
export class WorkOrdersResolver {
  constructor(private service: WorkOrdersService) {}

  @Query('workOrders')
  @UseGuards(GqlAuthGuard)
  async getWorkOrders(
    @Args('residentId', { nullable: true }) residentId?: string,
    @Args('status', { nullable: true }) status?: string,
  ) {
    return this.service.findAll(residentId, status);
  }

  @Query('workOrder')
  @UseGuards(GqlAuthGuard)
  async getWorkOrder(@Args('id') id: string) {
    return this.service.findOne(id);
  }

  @Mutation('createWorkOrder')
  @UseGuards(GqlAuthGuard)
  async create(@Args('input') input: any) {
    return this.service.create(input);
  }

  @Mutation('updateWorkOrderStatus')
  @UseGuards(GqlAuthGuard)
  async updateStatus(
    @Args('id') id: string,
    @Args('status') status: WorkOrderStatus,
    @Args('assignedToId', { nullable: true }) assignedToId?: string,
  ) {
    return this.service.updateStatus(id, status, assignedToId);
  }
}