import { Module } from '@nestjs/common';
import { ResidentsResolver } from './residents.resolver';
import { ResidentsService } from './residents.service';

@Module({
  providers: [ResidentsResolver, ResidentsService],
})
export class ResidentsModule {}