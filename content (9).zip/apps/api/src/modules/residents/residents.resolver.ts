import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { ResidentsService } from './residents.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';
import { Roles } from '../auth/decorators/roles.decorator';

@Resolver('Resident')
export class ResidentsResolver {
  constructor(private service: ResidentsService) {}

  @Query('residents')
  @UseGuards(GqlAuthGuard)
  async getResidents(@Args('communityId', { nullable: true }) communityId?: string) {
    return this.service.findAll(communityId);
  }

  @Query('resident')
  @UseGuards(GqlAuthGuard)
  async getResident(@Args('id') id: string) {
    return this.service.findOne(id);
  }

  @Mutation('createResident')
  @UseGuards(GqlAuthGuard)
  @Roles('ADMIN', 'PROPERTY_MANAGER')
  async create(@Args('input') input: any) {
    return this.service.create(input);
  }
}