import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ResidentsService {
  constructor(private prisma: PrismaService) {}

  async findAll(communityId?: string) {
    const where = communityId ? { communityId } : {};
    return this.prisma.resident.findMany({ where, include: { user: true, unit: true } });
  }

  async findOne(id: string) {
    return this.prisma.resident.findUnique({ where: { id }, include: { user: true, unit: true, community: true } });
  }

  async create(data: any) {
    return this.prisma.resident.create({ data, include: { user: true } });
  }

  async update(id: string, data: any) {
    return this.prisma.resident.update({ where: { id }, data });
  }
}