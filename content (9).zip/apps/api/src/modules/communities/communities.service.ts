import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class CommunitiesService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.community.findMany({ include: { units: true } });
  }

  async findOne(id: string) {
    return this.prisma.community.findUnique({ where: { id }, include: { units: true, residents: true } });
  }

  async create(data: any) {
    return this.prisma.community.create({ data });
  }

  async update(id: string, data: any) {
    return this.prisma.community.update({ where: { id }, data });
  }

  async remove(id: string) {
    return this.prisma.community.delete({ where: { id } });
  }
}