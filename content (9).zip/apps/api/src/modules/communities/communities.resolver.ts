import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { CommunitiesService } from './communities.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('Community')
export class CommunitiesResolver {
  constructor(private service: CommunitiesService) {}

  @Query('communities')
  @UseGuards(GqlAuthGuard)
  async getCommunities() {
    return this.service.findAll();
  }

  @Query('community')
  @UseGuards(GqlAuthGuard)
  async getCommunity(@Args('id') id: string) {
    return this.service.findOne(id);
  }

  @Mutation('createCommunity')
  @UseGuards(GqlAuthGuard)
  async create(@Args('input') input: any) {
    return this.service.create(input);
  }
}