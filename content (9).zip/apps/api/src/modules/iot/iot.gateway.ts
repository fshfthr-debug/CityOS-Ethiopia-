import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { UseGuards } from '@nestjs/common';
import { IoTService } from './iot.service';
import { WsJwtGuard } from '../../auth/guards/ws-jwt.guard';

@WebSocketGateway({
  namespace: 'iot',
  cors: { origin: '*' },
})
export class IoTGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  constructor(private iotService: IoTService) {}

  handleConnection(client: Socket) {
    console.log(`IoT client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    console.log(`IoT client disconnected: ${client.id}`);
  }

  @SubscribeMessage('subscribe-device')
  @UseGuards(WsJwtGuard)
  async handleSubscribe(client: Socket, deviceId: string) {
    client.join(`device:${deviceId}`);
    const readings = await this.iotService.getLatestReadings(deviceId, 24);
    client.emit('device-history', readings);
  }

  @SubscribeMessage('telemetry')
  async handleTelemetry(client: Socket, payload: { deviceId: string; data: any }) {
    const reading = await this.iotService.recordTelemetry(payload.deviceId, payload.data);
    this.server.to(`device:${payload.deviceId}`).emit('device-update', reading);
  }
}
