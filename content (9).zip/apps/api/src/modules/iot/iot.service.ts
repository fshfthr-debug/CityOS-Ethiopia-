import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { RedisService } from '../../redis/redis.service';

@Injectable()
export class IoTService {
  constructor(
    private prisma: PrismaService,
    private redis: RedisService,
  ) {}

  async findAll(communityId?: string) {
    const where = communityId ? { communityId } : {};
    return this.prisma.iotDevice.findMany({
      where,
      include: { community: true },
    });
  }

  async findOne(id: string) {
    return this.prisma.iotDevice.findUnique({
      where: { id },
      include: { community: true, readings: { orderBy: { recordedAt: 'desc' }, take: 100 } },
    });
  }

  async create(data: any) {
    return this.prisma.iotDevice.create({ data });
  }

  async recordTelemetry(deviceId: string, data: any) {
    const reading = await this.prisma.iotReading.create({
      data: {
        deviceId,
        ...data,
        recordedAt: new Date(),
      },
    });
    await this.redis.publish(`iot:${deviceId}`, JSON.stringify(data));
    return reading;
  }

  async getLatestReadings(deviceId: string, limit: number = 24) {
    return this.prisma.iotReading.findMany({
      where: { deviceId },
      orderBy: { recordedAt: 'desc' },
      take: limit,
    });
  }
}