import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { IoTService } from './iot.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('IoTDevice')
export class IoTResolver {
  constructor(private service: IoTService) {}

  @Query('iotDevices')
  @UseGuards(GqlAuthGuard)
  async getDevices(@Args('communityId', { nullable: true }) communityId?: string) {
    return this.service.findAll(communityId);
  }

  @Query('iotDevice')
  @UseGuards(GqlAuthGuard)
  async getDevice(@Args('id') id: string) {
    return this.service.findOne(id);
  }

  @Mutation('recordTelemetry')
  @UseGuards(GqlAuthGuard)
  async record(@Args('deviceId') deviceId: string, @Args('data') data: any) {
    return this.service.recordTelemetry(deviceId, data);
  }
}