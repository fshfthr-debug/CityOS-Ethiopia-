import { Module } from '@nestjs/common';
import { IoTResolver } from './iot.resolver';
import { IoTService } from './iot.service';
import { IoTGateway } from './iot.gateway';

@Module({
  providers: [IoTResolver, IoTService, IoTGateway],
})
export class IoTModule {}