import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { NotificationsService, NotificationType } from './notifications.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@Resolver('Notification')
export class NotificationsResolver {
  constructor(private service: NotificationsService) {}

  @Query('notifications')
  @UseGuards(GqlAuthGuard)
  async getNotifications(
    @CurrentUser() user: any,
    @Args('unreadOnly', { nullable: true }) unreadOnly?: boolean,
  ) {
    return this.service.findAll(user.userId, unreadOnly);
  }

  @Mutation('markNotificationAsRead')
  @UseGuards(GqlAuthGuard)
  async markRead(@Args('id') id: string) {
    return this.service.markAsRead(id);
  }

  @Mutation('markAllNotificationsAsRead')
  @UseGuards(GqlAuthGuard)
  async markAllRead(@CurrentUser() user: any) {
    return this.service.markAllAsRead(user.userId);
  }

  @Mutation('sendNotification')
  @UseGuards(GqlAuthGuard)
  async send(
    @Args('userId') userId: string,
    @Args('title') title: string,
    @Args('body') body: string,
    @Args('type') type: NotificationType,
  ) {
    return this.service.create(userId, title, body, type);
  }
}