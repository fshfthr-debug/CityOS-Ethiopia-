import { Module } from '@nestjs/common';
import { VisitorsResolver } from './visitors.resolver';
import { VisitorsService } from './visitors.service';

@Module({
  providers: [VisitorsResolver, VisitorsService],
})
export class VisitorsModule {}