import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { VisitorsService } from './visitors.service';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';

@Resolver('Visitor')
export class VisitorsResolver {
  constructor(private service: VisitorsService) {}

  @Query('visitors')
  @UseGuards(GqlAuthGuard)
  async getVisitors(
    @Args('residentId', { nullable: true }) residentId?: string,
    @Args('status', { nullable: true }) status?: string,
  ) {
    return this.service.findAll(residentId, status);
  }

  @Mutation('createVisitor')
  @UseGuards(GqlAuthGuard)
  async create(@Args('input') input: any) {
    return this.service.create(input);
  }

  @Mutation('checkInVisitor')
  @UseGuards(GqlAuthGuard)
  async checkIn(@Args('id') id: string) {
    return this.service.checkIn(id);
  }

  @Mutation('checkOutVisitor')
  @UseGuards(GqlAuthGuard)
  async checkOut(@Args('id') id: string) {
    return this.service.checkOut(id);
  }
}