import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class VisitorsService {
  constructor(private prisma: PrismaService) {}

  async findAll(residentId?: string, status?: string) {
    const where: any = {};
    if (residentId) where.residentId = residentId;
    if (status) where.status = status;
    return this.prisma.visitor.findMany({
      where,
      include: { resident: { include: { user: true } } },
      orderBy: { visitDate: 'desc' },
    });
  }

  async findOne(id: string) {
    return this.prisma.visitor.findUnique({
      where: { id },
      include: { resident: true },
    });
  }

  async create(data: any) {
    const passCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    return this.prisma.visitor.create({
      data: { ...data, passCode, status: 'PENDING' },
      include: { resident: true },
    });
  }

  async checkIn(id: string) {
    return this.prisma.visitor.update({
      where: { id },
      data: { status: 'CHECKED_IN', checkInTime: new Date() },
    });
  }

  async checkOut(id: string) {
    return this.prisma.visitor.update({
      where: { id },
      data: { status: 'CHECKED_OUT', checkOutTime: new Date() },
    });
  }
}