import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { join } from 'path';
import { ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';

import { AuthModule } from './modules/auth/auth.module';
import { CommunitiesModule } from './modules/communities/communities.module';
import { ResidentsModule } from './modules/residents/residents.module';
import { WorkOrdersModule } from './modules/work-orders/work-orders.module';
import { VisitorsModule } from './modules/visitors/visitors.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { MarketplaceModule } from './modules/marketplace/marketplace.module';
import { IoTModule } from './modules/iot/iot.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { PrismaModule } from './prisma/prisma.module';
import { RedisModule } from './redis/redis.module';
import { HealthModule } from './modules/health/health.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: ['.env', '../../.env'] }),
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      autoSchemaFile: join(process.cwd(), 'src/schema.gql'),
      sortSchema: true,
      playground: process.env.NODE_ENV !== 'production',
      introspection: true,
      subscriptions: {
        'graphql-ws': true,
      },
      context: ({ req, res }) => ({ req, res }),
    }),
    ThrottlerModule.forRoot([{
      ttl: 60000,
      limit: 100,
    }]),
    ScheduleModule.forRoot(),
    PrismaModule,
    RedisModule,
    AuthModule,
    CommunitiesModule,
    ResidentsModule,
    WorkOrdersModule,
    VisitorsModule,
    PaymentsModule,
    MarketplaceModule,
    IoTModule,
    NotificationsModule,
    HealthModule,
  ],
})
export class AppModule {}
