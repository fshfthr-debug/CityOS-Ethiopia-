#!/bin/bash
set -e

echo "CityOS - Quick Android Install (Development)"
echo "============================================="

# Check if device is connected
if ! adb devices | grep -q "device$"; then
    echo "No Android device detected. Please:"
    echo "  1. Enable USB debugging (Settings > Developer options)"
    echo "  2. Connect your phone via USB"
    echo "  3. Allow USB debugging on your phone"
    exit 1
fi

echo "Device detected!"

# Build and install debug APK
cd android
./gradlew installDebug

echo "App installed successfully!"
echo "Launching..."
adb shell monkey -p com.cityos.mobile -c android.intent.category.LAUNCHER 1
