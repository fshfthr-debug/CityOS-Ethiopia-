#!/bin/bash
set -e

echo "=========================================="
echo "  CityOS Android Build Script"
echo "=========================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
echo -e "${YELLOW}Checking prerequisites...${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js not found. Please install Node.js 20+${NC}"
    exit 1
fi

if ! command -v pnpm &> /dev/null; then
    echo -e "${RED}pnpm not found. Please install pnpm: npm install -g pnpm${NC}"
    exit 1
fi

if ! command -v java &> /dev/null; then
    echo -e "${RED}Java not found. Please install JDK 17+${NC}"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}Node.js 20+ required. Found: $(node -v)${NC}"
    exit 1
fi

echo -e "${GREEN}All prerequisites met!${NC}"

# Install dependencies
echo -e "${YELLOW}Installing dependencies...${NC}"
pnpm install

# Prebuild (generate native Android project)
echo -e "${YELLOW}Generating native Android project...${NC}"
npx expo prebuild --platform android

# Build APK
echo -e "${YELLOW}Building Android APK...${NC}"
cd android
./gradlew assembleRelease

# Find built APK
APK_PATH="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK_PATH" ]; then
    echo -e "${GREEN}Build successful!${NC}"
    echo -e "${GREEN}APK location: $(pwd)/$APK_PATH${NC}"
    echo ""
    echo "To install on your phone:"
    echo "  1. Enable USB debugging on your Android phone"
    echo "  2. Connect via USB"
    echo "  3. Run: adb install $(pwd)/$APK_PATH"
    echo ""
    echo "Or transfer the APK to your phone and install manually."
else
    echo -e "${RED}Build failed. Check logs above.${NC}"
    exit 1
fi
