import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../providers/theme-provider';

const visitors = [
  { id: '1', name: 'Sarah Johnson', purpose: 'Guest', date: 'Today, 2:00 PM', status: 'Pending', passCode: 'VIS1001' },
  { id: '2', name: 'Delivery Service', purpose: 'Delivery', date: 'Today, 4:30 PM', status: 'Approved', passCode: 'VIS1002' },
  { id: '3', name: 'Mike Repair', purpose: 'Service', date: 'Tomorrow, 9:00 AM', status: 'Approved', passCode: 'VIS1003' },
];

export function VisitorsScreen() {
  const { colors } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Visitors</Text>
        <TouchableOpacity style={[styles.addBtn, { backgroundColor: colors.primary }]}>
          <Ionicons name="add" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {visitors.map((v) => (
          <View key={v.id} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.cardHeader}>
              <View style={[styles.avatar, { backgroundColor: colors.primary + '20' }]}>
                <Text style={[styles.avatarText, { color: colors.primary }]}>{v.name[0]}</Text>
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardName, { color: colors.text }]}>{v.name}</Text>
                <Text style={[styles.cardMeta, { color: colors.textSecondary }]}>{v.purpose} • {v.date}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: v.status === 'Approved' ? '#10b98120' : '#f59e0b20' }]}>
                <Text style={[styles.statusText, { color: v.status === 'Approved' ? '#10b981' : '#f59e0b' }]}>{v.status}</Text>
              </View>
            </View>
            <View style={[styles.passCode, { backgroundColor: colors.background }]}>
              <Ionicons name="key-outline" size={14} color={colors.textSecondary} />
              <Text style={[styles.passCodeText, { color: colors.textSecondary }]}>Pass Code: </Text>
              <Text style={[styles.passCodeValue, { color: colors.text }]}>{v.passCode}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingBottom: 8 },
  title: { fontSize: 24, fontWeight: '700' },
  addBtn: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  scroll: { padding: 16, paddingTop: 8 },
  card: { padding: 16, borderRadius: 16, borderWidth: 1, marginBottom: 10 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 18, fontWeight: '700' },
  cardInfo: { flex: 1 },
  cardName: { fontSize: 15, fontWeight: '600' },
  cardMeta: { fontSize: 12, marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  statusText: { fontSize: 11, fontWeight: '600' },
  passCode: { flexDirection: 'row', alignItems: 'center', marginTop: 12, padding: 10, borderRadius: 10, gap: 6 },
  passCodeText: { fontSize: 12 },
  passCodeValue: { fontSize: 13, fontWeight: '700', fontFamily: 'monospace' },
});
