import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../providers/theme-provider';

const quickActions = [
  { icon: 'construct-outline' as const, label: 'New Work Order', color: '#3b82f6' },
  { icon: 'people-outline' as const, label: 'Register Visitor', color: '#10b981' },
  { icon: 'card-outline' as const, label: 'Pay Bill', color: '#f59e0b' },
  { icon: 'cart-outline' as const, label: 'Marketplace', color: '#8b5cf6' },
];

const stats = [
  { label: 'Work Orders', value: '3', icon: 'construct' as const, color: '#3b82f6' },
  { label: 'Due Soon', value: '$1,850', icon: 'card' as const, color: '#f59e0b' },
  { label: 'Visitors', value: '2', icon: 'people' as const, color: '#10b981' },
];

export function HomeScreen() {
  const { colors } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.textSecondary }]}>Good morning,</Text>
            <Text style={[styles.name, { color: colors.text }]}>John Smith</Text>
            <Text style={[styles.unit, { color: colors.textSecondary }]}>Unit 101 • Sunset Heights</Text>
          </View>
          <TouchableOpacity style={[styles.notificationBtn, { backgroundColor: colors.surface }]}>
            <Ionicons name="notifications-outline" size={22} color={colors.text} />
            <View style={styles.badge}>
              <Text style={styles.badgeText}>3</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.statsRow}>
          {stats.map((stat) => (
            <View key={stat.label} style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={[styles.statIcon, { backgroundColor: stat.color + '20' }]}>
                <Ionicons name={stat.icon} size={20} color={stat.color} />
              </View>
              <Text style={[styles.statValue, { color: colors.text }]}>{stat.value}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text }]}>Quick Actions</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((action) => (
            <TouchableOpacity
              key={action.label}
              style={[styles.actionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
            >
              <View style={[styles.actionIcon, { backgroundColor: action.color + '15' }]}>
                <Ionicons name={action.icon} size={24} color={action.color} />
              </View>
              <Text style={[styles.actionLabel, { color: colors.text }]}>{action.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text }]}>Recent Activity</Text>
        <View style={[styles.activityCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {[
            { icon: 'cube-outline' as const, text: 'Package delivered to front desk', time: '10 min ago', color: '#3b82f6' },
            { icon: 'construct-outline' as const, text: 'Work order assigned to Mike', time: '2 hrs ago', color: '#f59e0b' },
            { icon: 'checkmark-circle-outline' as const, text: 'Payment of $1,800 confirmed', time: '1 day ago', color: '#10b981' },
          ].map((item, i) => (
            <View key={i} style={[styles.activityItem, i < 2 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
              <View style={[styles.activityIcon, { backgroundColor: item.color + '15' }]}>
                <Ionicons name={item.icon} size={18} color={item.color} />
              </View>
              <View style={styles.activityContent}>
                <Text style={[styles.activityText, { color: colors.text }]} numberOfLines={1}>{item.text}</Text>
                <Text style={[styles.activityTime, { color: colors.textSecondary }]}>{item.time}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  greeting: { fontSize: 14 },
  name: { fontSize: 24, fontWeight: '700', marginTop: 2 },
  unit: { fontSize: 13, marginTop: 4 },
  notificationBtn: { padding: 10, borderRadius: 12, position: 'relative' },
  badge: { position: 'absolute', top: 6, right: 6, backgroundColor: '#ef4444', borderRadius: 10, minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  statCard: { flex: 1, padding: 14, borderRadius: 16, borderWidth: 1, alignItems: 'center' },
  statIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  statValue: { fontSize: 18, fontWeight: '700' },
  statLabel: { fontSize: 11, marginTop: 2 },
  sectionTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 24 },
  actionCard: { width: '47%', padding: 16, borderRadius: 16, borderWidth: 1, alignItems: 'center' },
  actionIcon: { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  actionLabel: { fontSize: 13, fontWeight: '500' },
  activityCard: { borderRadius: 16, borderWidth: 1, overflow: 'hidden', marginBottom: 20 },
  activityItem: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  activityIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  activityContent: { flex: 1 },
  activityText: { fontSize: 13, fontWeight: '500' },
  activityTime: { fontSize: 11, marginTop: 2 },
});
