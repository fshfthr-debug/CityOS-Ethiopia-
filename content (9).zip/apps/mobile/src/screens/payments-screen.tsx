import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../providers/theme-provider';

const payments = [
  { id: '1', description: 'Monthly Rent - June 2026', amount: 1800, status: 'Paid', date: 'Jun 1, 2026' },
  { id: '2', description: 'Utilities - May 2026', amount: 145.5, status: 'Paid', date: 'May 28, 2026' },
  { id: '3', description: 'Service Charge - Q2 2026', amount: 250, status: 'Due', date: 'Due Jun 15' },
];

export function PaymentsScreen() {
  const { colors } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Payments</Text>
      </View>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={[styles.summaryCard, { backgroundColor: colors.primary }]}>
          <Text style={styles.summaryLabel}>Total Due</Text>
          <Text style={styles.summaryAmount}>$1,850.00</Text>
          <Text style={styles.summarySubtext}>Due by June 15, 2026</Text>
          <TouchableOpacity style={styles.payBtn}>
            <Text style={styles.payBtnText}>Pay Now</Text>
          </TouchableOpacity>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text }]}>Payment History</Text>
        {payments.map((p) => (
          <View key={p.id} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.cardRow}>
              <View style={styles.cardLeft}>
                <Text style={[styles.cardDesc, { color: colors.text }]}>{p.description}</Text>
                <Text style={[styles.cardDate, { color: colors.textSecondary }]}>{p.date}</Text>
              </View>
              <View style={styles.cardRight}>
                <Text style={[styles.cardAmount, { color: colors.text }]}>${p.amount.toFixed(2)}</Text>
                <View style={[styles.statusBadge, { backgroundColor: p.status === 'Paid' ? '#10b98120' : '#f59e0b20' }]}>
                  <Text style={[styles.statusText, { color: p.status === 'Paid' ? '#10b981' : '#f59e0b' }]}>{p.status}</Text>
                </View>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { padding: 16, paddingBottom: 8 },
  title: { fontSize: 24, fontWeight: '700' },
  scroll: { padding: 16, paddingTop: 8 },
  summaryCard: { padding: 24, borderRadius: 20, marginBottom: 20 },
  summaryLabel: { color: 'rgba(255,255,255,0.8)', fontSize: 14 },
  summaryAmount: { color: '#fff', fontSize: 36, fontWeight: '700', marginVertical: 4 },
  summarySubtext: { color: 'rgba(255,255,255,0.8)', fontSize: 13 },
  payBtn: { backgroundColor: '#fff', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12, alignSelf: 'flex-start', marginTop: 16 },
  payBtnText: { color: '#3b82f6', fontWeight: '700', fontSize: 15 },
  sectionTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12 },
  card: { padding: 16, borderRadius: 16, borderWidth: 1, marginBottom: 10 },
  cardRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardLeft: { flex: 1 },
  cardDesc: { fontSize: 14, fontWeight: '600' },
  cardDate: { fontSize: 12, marginTop: 4 },
  cardRight: { alignItems: 'flex-end' },
  cardAmount: { fontSize: 16, fontWeight: '700' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, marginTop: 4 },
  statusText: { fontSize: 11, fontWeight: '600' },
});
