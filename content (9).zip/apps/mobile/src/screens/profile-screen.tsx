import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../providers/theme-provider';

const menuItems = [
  { icon: 'person-outline' as const, label: 'Edit Profile', color: '#3b82f6' },
  { icon: 'shield-checkmark-outline' as const, label: 'Security', color: '#10b981' },
  { icon: 'notifications-outline' as const, label: 'Notifications', color: '#f59e0b' },
  { icon: 'card-outline' as const, label: 'Payment Methods', color: '#8b5cf6' },
  { icon: 'document-text-outline' as const, label: 'Documents', color: '#64748b' },
  { icon: 'help-circle-outline' as const, label: 'Help & Support', color: '#3b82f6' },
  { icon: 'log-out-outline' as const, label: 'Sign Out', color: '#ef4444' },
];

export function ProfileScreen() {
  const { colors, theme, toggleTheme } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.profileHeader}>
          <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
            <Text style={styles.avatarText}>JS</Text>
          </View>
          <Text style={[styles.name, { color: colors.text }]}>John Smith</Text>
          <Text style={[styles.email, { color: colors.textSecondary }]}>john.smith@email.com</Text>
          <Text style={[styles.unit, { color: colors.textSecondary }]}>Unit 101 • Sunset Heights</Text>
        </View>

        <View style={[styles.toggleRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.toggleLeft}>
            <Ionicons name={theme === 'dark' ? 'moon-outline' : 'sunny-outline'} size={20} color={colors.text} />
            <Text style={[styles.toggleLabel, { color: colors.text }]}>Dark Mode</Text>
          </View>
          <Switch value={theme === 'dark'} onValueChange={toggleTheme} trackColor={{ false: '#e2e8f0', true: '#3b82f6' }} />
        </View>

        <View style={[styles.menuCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {menuItems.map((item, i) => (
            <TouchableOpacity
              key={item.label}
              style={[styles.menuItem, i < menuItems.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
            >
              <View style={styles.menuLeft}>
                <Ionicons name={item.icon} size={20} color={item.color} />
                <Text style={[styles.menuLabel, { color: colors.text }]}>{item.label}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  profileHeader: { alignItems: 'center', paddingVertical: 30 },
  avatar: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  avatarText: { color: '#fff', fontSize: 28, fontWeight: '700' },
  name: { fontSize: 20, fontWeight: '700' },
  email: { fontSize: 14, marginTop: 4 },
  unit: { fontSize: 13, marginTop: 2 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 16, padding: 16, borderRadius: 16, borderWidth: 1, marginBottom: 16 },
  toggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  toggleLabel: { fontSize: 15, fontWeight: '500' },
  menuCard: { marginHorizontal: 16, borderRadius: 16, borderWidth: 1, overflow: 'hidden', marginBottom: 30 },
  menuItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16 },
  menuLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  menuLabel: { fontSize: 15, fontWeight: '500' },
});
