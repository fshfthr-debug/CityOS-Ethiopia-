import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../providers/theme-provider';

const workOrders = [
  { id: '1', title: 'Leaky faucet in kitchen', status: 'In Progress', priority: 'Medium', date: '2 days ago' },
  { id: '2', title: 'AC not cooling properly', status: 'Pending', priority: 'High', date: '1 day ago' },
  { id: '3', title: 'Light fixture replacement', status: 'Completed', priority: 'Low', date: '5 days ago' },
];

const statusColors: Record<string, string> = {
  'Pending': '#f59e0b',
  'In Progress': '#3b82f6',
  'Completed': '#10b981',
};

export function WorkOrdersScreen() {
  const { colors } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Work Orders</Text>
        <TouchableOpacity style={[styles.addBtn, { backgroundColor: colors.primary }]}>
          <Ionicons name="add" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {workOrders.map((wo) => (
          <View key={wo.id} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.cardHeader}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{wo.title}</Text>
              <View style={[styles.statusBadge, { backgroundColor: statusColors[wo.status] + '20' }]}>
                <Text style={[styles.statusText, { color: statusColors[wo.status] }]}>{wo.status}</Text>
              </View>
            </View>
            <View style={styles.cardFooter}>
              <Text style={[styles.cardDate, { color: colors.textSecondary }]}>{wo.date}</Text>
              <Text style={[styles.priority, { color: wo.priority === 'High' ? '#ef4444' : colors.textSecondary }]}>{wo.priority}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingBottom: 8 },
  title: { fontSize: 24, fontWeight: '700' },
  addBtn: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  scroll: { padding: 16, paddingTop: 8 },
  card: { padding: 16, borderRadius: 16, borderWidth: 1, marginBottom: 10 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 },
  cardTitle: { fontSize: 15, fontWeight: '600', flex: 1, marginRight: 8 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  statusText: { fontSize: 11, fontWeight: '600' },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardDate: { fontSize: 12 },
  priority: { fontSize: 12, fontWeight: '500' },
});
