import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

// Use your computer's local IP for physical Android device
// Find your IP: ipconfig (Windows) or ifconfig (Mac/Linux)
const LOCAL_IP = '192.168.1.100'; // <-- CHANGE THIS TO YOUR COMPUTER'S IP

const API_URL = Platform.select({
  ios: 'http://localhost:4000/graphql',
  android: __DEV__ 
    ? `http://${LOCAL_IP}:4000/graphql`  // Physical device via WiFi
    : 'https://api.cityos.local/graphql', // Production
  default: 'http://localhost:4000/graphql',
});

const httpLink = createHttpLink({
  uri: API_URL,
});

const authLink = setContext(async (_, { headers }) => {
  const token = await AsyncStorage.getItem('token');
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : '',
    },
  };
});

export const apolloClient = new ApolloClient({
  link: authLink.concat(httpLink),
  cache: new InMemoryCache(),
});
